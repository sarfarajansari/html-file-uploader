from django.apps import AppConfig


class HtmlmanagerConfig(AppConfig):
    name = 'htmlmanager'
